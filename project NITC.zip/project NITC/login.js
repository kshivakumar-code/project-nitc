function validate()
{
    var username=document.getElementById("username").value;
    var password=document.getElementById("password").value;
if(username=="shiva"&&password=="project")
{
    window.location.replace=("./index.html")

 }
else{
    alert("invaild Login Details");
    return ;

 }

}
